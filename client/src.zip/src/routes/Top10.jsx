export default function Top10() {
    return(
        <main style={{padding: '1em, 0'}}>
        <h2>Top10</h2>
        </main>
    )
}