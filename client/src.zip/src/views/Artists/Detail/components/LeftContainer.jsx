import ArtistImage from "./ArtistImage";

const LeftContainer = ({ imageUrl }) => {
 return (
  <ArtistImage url={imageUrl} />
 );
};

export default LeftContainer;