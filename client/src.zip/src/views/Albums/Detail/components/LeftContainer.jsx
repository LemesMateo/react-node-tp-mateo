import AlbumImage from "./AlbumImage";

const LeftContainer = ({ imageUrl }) => {
 return (
  <AlbumImage url={imageUrl} />
 );
};

export default LeftContainer;